import {test} from 'node:test';import assert from 'node:assert/strict';import {readFileSync,existsSync} from 'node:fs';import {execFileSync,spawnSync} from 'node:child_process';
const root=new URL('../',import.meta.url);const read=p=>readFileSync(new URL(p,root),'utf8');
test('preview is HTTPS, exact-host and release guard fails closed',()=>{
 const c=JSON.parse(read('capacitor.config.json'));assert.equal(c.server.url,'https://thirteen-go-test.onrender.com/mobile-preview');assert.equal(c.server.cleartext,false);assert.equal(c.appId,'com.saistudio.go13.preview');assert(!c.server.allowNavigation);
 const result=spawnSync(process.execPath,['scripts/release-check.mjs'],{cwd:root,encoding:'utf8'});assert.equal(result.status,1);assert.match(result.stderr,/RELEASE BLOCKED/);
});
test('both native projects carry portrait, plugin registration and audio resources',()=>{
 execFileSync('python',['-c',`import plistlib;d=plistlib.load(open('ios/App/App/Info.plist','rb'));assert d['UISupportedInterfaceOrientations']==['UIInterfaceOrientationPortrait'];assert d['WKAppBoundDomains']==['thirteen-go-test.onrender.com','localhost']`],{cwd:root});
 assert.match(read('ios/App/App/Base.lproj/Main.storyboard'),/Go13ViewController/);assert.match(read('ios/App/App.xcodeproj/project.pbxproj'),/Go13AudioPlugin.swift in Sources/);
 assert.match(read('android/app/src/main/AndroidManifest.xml'),/screenOrientation="portrait"/);assert.match(read('android/app/src/main/java/com/saistudio/go13/preview/MainActivity.java'),/registerPlugin\(Go13AudioPlugin.class\)/);
 for(const platform of ['ios/App/App/public','android/app/src/main/assets/public'])for(const sound of ['stone','intro','cue','urgent'])assert(existsSync(new URL(platform+'/audio/'+sound+'.wav',root)));
});
