import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createAudioController} from '../src/audio-controller.js';
test('web never invokes native audio',async()=>{
 const audio=createAudioController({native:false,plugin:{prepare(){throw Error('native invoked')}}});
 assert.equal(await audio.initialize(),false);assert.equal(audio.play('stone'),false);
});
test('native waits for prepare, validates cues, clamps gain and delay, and stops',async()=>{
 const played=[];let stopped=0,hidden=false,ready=0;
 const plugin={prepare:async()=>{},play:async x=>played.push(x),stop:async()=>{stopped++}};
 const audio=createAudioController({native:true,plugin,isHidden:()=>hidden,onReady:()=>ready++});
 assert.equal(audio.play('stone'),false);assert.equal(await audio.initialize(),true);assert.equal(ready,1);
 assert.equal(audio.play('stone',4,10),true);assert.deepEqual(played[0],{kind:'stone',volume:1,delay:0.8});
 assert.equal(audio.play('../private'),false);assert.equal(audio.play('stone',NaN),false);
 hidden=true;assert.equal(audio.play('cue'),false);audio.stop();assert.equal(stopped,1);
});
test('failed native initialization/play disables later audio calls',async()=>{
 const unavailable=createAudioController({native:true,plugin:{prepare:async()=>{throw Error('unavailable')}}});assert.equal(await unavailable.initialize(),false);
 const audio=createAudioController({native:true,plugin:{prepare:async()=>{},play:async()=>{throw Error('lost')}}});
 await audio.initialize();audio.play('intro');await new Promise(resolve=>setTimeout(resolve,0));assert.equal(audio.canPlay(),false);assert.equal(audio.play('stone'),false);
});
