import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createAppAdapter} from '../src/app-adapter.js';
test('bundled adapter routes assets locally, guest requests natively and preserves server validation errors',async()=>{
 let stored=null;const calls=[];const token='s'.repeat(43),ticket='t'.repeat(43);
 const plugin={get:async()=>({value:stored}),set:async({value})=>{stored=value},remove:async()=>{stored=null}};
 const request=async options=>{calls.push(options);return {status:options.url.endsWith('/rooms')?409:200,data:options.url.endsWith('/session')?JSON.stringify({token,expiresAt:Date.now()/1000+3600}):options.url.endsWith('/socket-ticket')?JSON.stringify({ticket}):options.url.endsWith('/rooms')?'Finish your current game':JSON.stringify({profile:{id:'same-user'}})}};
 const make=()=>createAppAdapter({request,plugin,assetFetch:async path=>new Response('local:'+path)});
 const app=make();
 assert.match(await (await app.fetch('/static/stone-placement.wav')).text(),/^local:/);
 assert.deepEqual(await (await app.fetch('/api/auth/me')).json(),{user:null,games:[]});assert.equal(calls.length,0);
 assert.equal((await (await app.fetch('/api/profile')).json()).profile.id,'same-user');
 const error=await app.fetch('/api/rooms',{method:'POST',body:JSON.stringify({solo:true})});
 assert.equal(error.status,409);assert.equal(await error.text(),'Finish your current game');
 assert.equal(await make().socketUrl(),'wss://thirteen-go-test.onrender.com/ws/native?ticket='+ticket);
 assert.equal(calls.filter(c=>c.url.endsWith('/session')).length,1);
 await assert.rejects(app.fetch('https://evil.example/api/profile'),/Unsupported/);
 assert.notEqual(stored,null);await app.resetGuest();assert.equal(stored,null);
});
test('secure read failure never creates a replacement identity or leaks into asset transport',async()=>{
 let requests=0;
 const app=createAppAdapter({request:async()=>{requests++},plugin:{get:async()=>{throw Error('locked')},set:async()=>{},remove:async()=>{}},assetFetch:async()=>{throw Error('not an asset')}});
 await assert.rejects(app.fetch('/api/profile'),{code:'SECURE_READ_FAILED'});assert.equal(requests,0);
});
