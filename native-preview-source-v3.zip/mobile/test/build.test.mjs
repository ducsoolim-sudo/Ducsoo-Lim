import {test} from 'node:test';
import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import vm from 'node:vm';
import {inspectEnvironment} from '../scripts/native-environment.mjs';
const root=new URL('../',import.meta.url);
test('native prerequisites reject old Java, absent SDK, and non-Mac iOS builds',()=>{
 const state=inspectEnvironment({platform:'linux',javaVersion:'openjdk version "17.0.1"',sdk:'',nodeMajor:24});
 assert.equal(state.android.ready,false);assert.match(state.android.missing.join(','),/JDK 21/);
 assert.equal(state.ios.ready,false);assert.match(state.ios.missing.join(','),/macOS/);
 const partial=inspectEnvironment({platform:'darwin',javaVersion:'openjdk version "21.0.4"',sdk:'/sdk',exists:p=>!p.includes('android.jar'),xcode:true,nodeMajor:24});
 assert.equal(partial.ios.ready,true);assert.deepEqual(partial.android.missing,['Android SDK platform 36']);
});
test('staged UI contains verified assets and cannot silently replace remote preview',()=>{
 const before=readFileSync(new URL('capacitor.config.json',root),'utf8');
 execFileSync(process.execPath,['scripts/stage-frontend.mjs'],{cwd:root});
 assert.equal(readFileSync(new URL('capacitor.config.json',root),'utf8'),before);
 const manifest=JSON.parse(readFileSync(new URL('staged-frontend/manifest.json',root),'utf8'));
 assert.equal(manifest.runnable,false);assert(manifest.blockers.includes('device-validation'));
 for(const asset of manifest.assets){const data=readFileSync(new URL('staged-frontend/'+asset.file,root));assert.equal(data.length,asset.bytes);assert.equal(createHash('sha256').update(data).digest('hex'),asset.sha256)}
 const html=readFileSync(new URL('staged-frontend/index.html',root),'utf8');
 const script=html.match(/<script>([\s\S]*?)<\/script>/)[1];
 new vm.Script(script);
 assert.match(script,/await window.Go13App.socketUrl\(\)/);
 assert.match(script,/epoch!==nativeConnectEpoch\|\|room!==targetRoom/);
 assert(!script.includes("new WebSocket(protocol+'//'+location.host"));
 assert(html.indexOf('/static/mobile-bridge.js')<html.indexOf('<script>'));
 for(const match of html.matchAll(/(?:src|href)="(\/static\/[^"?]+)(?:\?[^\"]*)?"/g))assert(manifest.assets.some(a=>'/'+a.file===match[1]));
});
