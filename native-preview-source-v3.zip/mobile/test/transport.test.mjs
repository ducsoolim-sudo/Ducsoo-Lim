import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createGuestTransport} from '../src/guest-transport.js';
const token='s'.repeat(43),ticket='t'.repeat(43),saved={token,expiresAt:200};
function fixture(initial=null){
 let value=initial;const calls=[];
 const store={get:async()=>value,set:async v=>{value=v},remove:async()=>{value=null}};
 const request=async r=>{calls.push(r);return {status:200,data:r.url.endsWith('/session')?saved:r.url.endsWith('/socket-ticket')?{ticket}: {ok:true}}};
 return {calls,store,request,read:()=>value};
}
test('concurrent native requests persist one guest session before sending and reuse it after restart',async()=>{
 const f=fixture();const transport=createGuestTransport({request:f.request,sessionStore:f.store,now:()=>100});
 await Promise.all([transport.api('/api/profile'),transport.api('/api/lobby')]);
 assert.equal(f.calls.filter(r=>r.url.endsWith('/session')).length,1);
 assert.deepEqual(f.read(),saved);
 const restarted=createGuestTransport({request:f.request,sessionStore:f.store,now:()=>100});
 assert.equal(await restarted.socketUrl(),'wss://thirteen-go-test.onrender.com/ws/native?ticket='+ticket);
 assert.equal(f.calls.at(-1).headers.Authorization,'Bearer '+token);
 assert(!f.calls.at(-1).url.includes(token));
 await restarted.revoke();assert.equal(f.read(),null);
});
test('expired or revoked credentials never silently create a new guest identity',async()=>{
 for(const initial of [{...saved,expiresAt:99},saved]){
  const f=fixture(initial);
  const transport=createGuestTransport({request:async r=>{f.calls.push(r);return {status:401}},sessionStore:f.store,now:()=>100});
  await assert.rejects(transport.api('/api/profile'),{code:'SESSION_EXPIRED'});
  assert(!f.calls.some(r=>r.url.endsWith('/session')));assert.deepEqual(f.read(),initial);
 }
});
test('secure storage failures stop room creation and arbitrary destinations are rejected',async()=>{
 const f=fixture();f.store.set=async()=>{throw Error('keychain unavailable')};
 const transport=createGuestTransport({request:f.request,sessionStore:f.store,now:()=>100});
 await assert.rejects(transport.api('/api/rooms',{method:'POST',data:{solo:true}}),/keychain/);
 assert.equal(f.calls.length,1);
 await assert.rejects(transport.api('https://evil.example/api/profile'),/Unsupported/);
 assert.equal(f.calls.length,1);
});
