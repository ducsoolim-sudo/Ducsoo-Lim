// Real server + JS adapter; native secure storage/HTTP are simulated here.
import {test} from 'node:test';
import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {createAppAdapter} from '../src/app-adapter.js';
test('bundled adapter creates a real server guest and resumes the same played seat',{timeout:15000},async()=>{
 const child=spawn('python',['-u','-c',`import asyncio
from aiohttp import web
import server
from storage import RoomStore
async def main():
 runner=web.AppRunner(server.make_app(RoomStore(path=':memory:',database_url='')))
 await runner.setup()
 site=web.TCPSite(runner,'127.0.0.1',0)
 await site.start()
 print(site._server.sockets[0].getsockname()[1],flush=True)
 await asyncio.Event().wait()
asyncio.run(main())`],{cwd:fileURLToPath(new URL('../../',import.meta.url)),env:{...process.env,GO13_PREVIEW:'true',GO13_NATIVE_PREVIEW:'true'},stdio:['ignore','pipe','pipe']});
 let diagnostics='';child.stderr.on('data',chunk=>{diagnostics+=chunk});
 const sockets=[];
 try{
  const port=await new Promise((resolve,reject)=>{
   const timer=setTimeout(()=>reject(Error('Test server startup timed out: '+diagnostics)),5000);
   child.once('error',error=>{clearTimeout(timer);reject(error)});
   child.once('exit',()=>{clearTimeout(timer);reject(Error('Test server stopped: '+diagnostics))});
   child.stdout.once('data',data=>{clearTimeout(timer);const p=Number(String(data).trim());Number.isInteger(p)&&p>0?resolve(p):reject(Error('Invalid test port'))});
  });
  let encryptedStoreMock=null; // Not a Keychain/Keystore device test.
  const plugin={get:async()=>({value:encryptedStoreMock}),set:async({value})=>{encryptedStoreMock=value},remove:async()=>{encryptedStoreMock=null}};
  const request=async options=>{
   const url=new URL(options.url);assert.equal(url.origin,'https://thirteen-go-test.onrender.com');
   const response=await fetch('http://127.0.0.1:'+port+url.pathname,{method:options.method,headers:options.headers,...(options.data!==undefined?{body:JSON.stringify(options.data)}:{})});
   return {status:response.status,data:await response.text()};
  };
  const app=()=>createAppAdapter({request,plugin,assetFetch:fetch});
  const first=app();const profile=await (await first.fetch('/api/profile')).json();
  const room=await (await first.fetch('/api/rooms',{method:'POST',body:'{"solo":true}'})).json();
  async function join(adapter){
   const endpoint=new URL(await adapter.socketUrl());
   const ws=new WebSocket('ws://127.0.0.1:'+port+endpoint.pathname+endpoint.search);sockets.push(ws);
   const messages=[];let wake;
   ws.addEventListener('message',e=>{messages.push(JSON.parse(e.data));wake?.();wake=null});
   const next=async()=>{if(!messages.length)await new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('Socket message timed out')),3000);wake=()=>{clearTimeout(timer);resolve()}});return messages.shift()};
   await new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('Socket open timed out')),3000);ws.addEventListener('open',()=>{clearTimeout(timer);resolve()},{once:true});ws.addEventListener('error',error=>{clearTimeout(timer);reject(error)},{once:true})});
   ws.send(JSON.stringify({type:'join',room:room.room,token:room.token}));
   assert.equal((await next()).role,'black');
   return {ws,next,state:await next()};
  }
  const live=await join(first);assert.equal(live.state.state.moves,0);
  live.ws.send(JSON.stringify({type:'move',index:84}));assert.equal((await live.next()).state.moves,1);
  await new Promise(resolve=>{live.ws.addEventListener('close',resolve,{once:true});live.ws.close()});
  const restarted=app();assert.equal((await (await restarted.fetch('/api/profile')).json()).profile.id,profile.profile.id);
  const resumed=await join(restarted);assert.equal(resumed.state.state.moves,1);
 }finally{
  for(const socket of sockets)socket.close();
  child.kill('SIGTERM');
 }
});
