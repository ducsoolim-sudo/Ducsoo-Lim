package com.saistudio.go13.preview;
import android.os.Bundle;
import com.getcapacitor.BridgeActivity;
public class MainActivity extends BridgeActivity {
    @Override public void onCreate(Bundle state) {
        registerPlugin(Go13AudioPlugin.class);
        registerPlugin(Go13SessionPlugin.class);
        super.onCreate(state);
    }
}
