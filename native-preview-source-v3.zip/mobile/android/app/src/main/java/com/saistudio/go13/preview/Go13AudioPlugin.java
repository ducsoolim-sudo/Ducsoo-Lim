package com.saistudio.go13.preview;

import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.SoundPool;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.Map;
import java.util.List;

@CapacitorPlugin(name = "Go13Audio")
public class Go13AudioPlugin extends Plugin {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Map<String,Integer> sounds = new HashMap<>();
    private final List<Integer> streams = new ArrayList<>();
    private final List<PluginCall> waiting = new ArrayList<>();
    private SoundPool pool;
    private int loaded = 0;
    private boolean failed = false;
    private boolean trusted() {
        String location = getBridge().getWebView().getUrl();
        if(location == null) return false;
        Uri url = Uri.parse(location);
        return "https".equals(url.getScheme()) && ("thirteen-go-test.onrender.com".equals(url.getHost()) || "localhost".equals(url.getHost()));
    }
    @Override public void load() {
        pool = new SoundPool.Builder().setMaxStreams(8).setAudioAttributes(
            new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()).build();
        pool.setOnLoadCompleteListener((soundPool, id, status) -> handler.post(() -> {
            if(status != 0) failed = true;
            loaded++;
            if(loaded == 4) {
                for(PluginCall call : waiting) { if(failed) call.reject("Audio unavailable"); else call.resolve(); }
                waiting.clear();
            }
        }));
        for(String kind : new String[]{"stone","intro","cue","urgent"}) {
            try(AssetFileDescriptor asset = getContext().getAssets().openFd("public/audio/" + kind + ".wav")) {
                int id = pool.load(asset,1); sounds.put(kind,id);
                if(id == 0) { failed = true; loaded++; }
            } catch(Exception error) { failed = true; loaded++; }
        }
    }
    @PluginMethod public void prepare(PluginCall call) {
        getActivity().runOnUiThread(() -> {
            if(!trusted()) { call.reject("Untrusted origin"); return; }
            if(failed) { call.reject("Audio unavailable"); return; }
            if(loaded == 4) call.resolve(); else waiting.add(call);
        });
    }
    @PluginMethod public void play(PluginCall call) {
        getActivity().runOnUiThread(() -> {
            String kind = call.getString("kind");
            Double volume = call.getDouble("volume",0.7), delay = call.getDouble("delay",0.0);
            if(!trusted() || !sounds.containsKey(kind) || failed || loaded != 4 || !Double.isFinite(volume) || !Double.isFinite(delay)) { call.reject("Audio unavailable"); return; }
            AudioManager manager = (AudioManager)getContext().getSystemService(Context.AUDIO_SERVICE);
            if(manager.getRingerMode() != AudioManager.RINGER_MODE_NORMAL || !getActivity().hasWindowFocus()) { call.resolve(); return; }
            final float gain = (float)Math.min(1,Math.max(0,volume));
            handler.postDelayed(() -> {
                if(manager.getRingerMode() == AudioManager.RINGER_MODE_NORMAL && getActivity().hasWindowFocus()) {
                    int stream = pool.play(sounds.get(kind),gain,gain,1,0,1);
                    streams.add(stream); if(streams.size()>16) pool.stop(streams.remove(0));
                }
            },(long)(Math.min(0.8,Math.max(0,delay))*1000));
            call.resolve();
        });
    }
    private void silence() { handler.removeCallbacksAndMessages(null); for(int stream:streams) pool.stop(stream); streams.clear(); }
    @PluginMethod public void stop(PluginCall call) { getActivity().runOnUiThread(() -> { silence(); call.resolve(); }); }
    @Override protected void handleOnPause() { silence(); }
    @Override protected void handleOnDestroy() { silence(); for(PluginCall call:waiting) call.reject("App closed"); waiting.clear(); pool.release(); }
}
