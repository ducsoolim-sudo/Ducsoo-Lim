package com.saistudio.go13.preview;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import org.json.JSONObject;

@CapacitorPlugin(name = "Go13Session")
public class Go13SessionPlugin extends Plugin {
    private static final String ALIAS = "go13-preview-guest";
    private SharedPreferences prefs() { return getContext().getSharedPreferences("go13-secure-session", Context.MODE_PRIVATE); }
    private void local(PluginCall call, Runnable work) {
        getActivity().runOnUiThread(() -> {
            String location = getBridge().getWebView().getUrl();
            Uri url = location == null ? Uri.EMPTY : Uri.parse(location);
            if (!"https".equals(url.getScheme()) || !"localhost".equals(url.getHost())) {
                call.reject("Local app required"); return;
            }
            work.run();
        });
    }
    private SecretKey key(boolean create) throws Exception {
        KeyStore store = KeyStore.getInstance("AndroidKeyStore"); store.load(null);
        if (store.containsAlias(ALIAS)) return (SecretKey) store.getKey(ALIAS, null);
        if (!create) throw new IllegalStateException("Secure key missing");
        KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        generator.init(new KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());
        return generator.generateKey();
    }
    @PluginMethod public void get(PluginCall call) {
        local(call, () -> {
            try {
                String stored = prefs().getString("session", null);
                JSObject result = new JSObject();
                if (stored == null) { result.put("value", JSONObject.NULL); call.resolve(result); return; }
                JSONObject envelope = new JSONObject(stored);
                Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
                cipher.init(Cipher.DECRYPT_MODE, key(false), new GCMParameterSpec(128, Base64.decode(envelope.getString("iv"), Base64.NO_WRAP)));
                String value = new String(cipher.doFinal(Base64.decode(envelope.getString("data"), Base64.NO_WRAP)), StandardCharsets.UTF_8);
                result.put("value", value); call.resolve(result);
            } catch (Exception e) { call.reject("Secure session unavailable"); }
        });
    }
    @PluginMethod public void set(PluginCall call) {
        local(call, () -> {
            try {
                String value = call.getString("value");
                if (value == null || value.getBytes(StandardCharsets.UTF_8).length > 4096) throw new IllegalArgumentException();
                Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding"); cipher.init(Cipher.ENCRYPT_MODE, key(true));
                JSONObject envelope = new JSONObject();
                envelope.put("iv", Base64.encodeToString(cipher.getIV(), Base64.NO_WRAP));
                envelope.put("data", Base64.encodeToString(cipher.doFinal(value.getBytes(StandardCharsets.UTF_8)), Base64.NO_WRAP));
                if (!prefs().edit().putString("session", envelope.toString()).commit()) throw new IllegalStateException();
                call.resolve();
            } catch (Exception e) { call.reject("Secure session write failed"); }
        });
    }
    @PluginMethod public void remove(PluginCall call) {
        local(call, () -> {
            if (!prefs().edit().remove("session").commit()) { call.reject("Secure session removal failed"); return; }
            call.resolve();
        });
    }
}
