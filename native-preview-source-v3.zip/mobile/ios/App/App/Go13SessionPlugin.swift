import Foundation
import Capacitor
import Security

@objc(Go13SessionPlugin)
public class Go13SessionPlugin: CAPPlugin, CAPBridgedPlugin {
    public let identifier = "Go13SessionPlugin"
    public let jsName = "Go13Session"
    public let pluginMethods: [CAPPluginMethod] = [
        CAPPluginMethod(name: "get", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "set", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "remove", returnType: CAPPluginReturnPromise)
    ]
    private var query: [String: Any] {
        [kSecClass as String: kSecClassGenericPassword,
         kSecAttrService as String: "com.saistudio.go13.preview.session",
         kSecAttrAccount as String: "guest"]
    }
    private func local(_ call: CAPPluginCall, _ work: @escaping () -> Void) {
        DispatchQueue.main.async { [weak self] in
            guard let url = self?.bridge?.webView?.url,
                  url.scheme == "capacitor", url.host == "localhost" else {
                call.reject("Local app required"); return
            }
            work()
        }
    }
    @objc public func get(_ call: CAPPluginCall) {
        local(call) {
            var query = self.query
            query[kSecReturnData as String] = true
            query[kSecMatchLimit as String] = kSecMatchLimitOne
            var result: CFTypeRef?
            let status = SecItemCopyMatching(query as CFDictionary, &result)
            if status == errSecItemNotFound { call.resolve(["value": NSNull()]); return }
            guard status == errSecSuccess, let data = result as? Data,
                  let value = String(data: data, encoding: .utf8) else {
                call.reject("Secure session unavailable"); return
            }
            call.resolve(["value": value])
        }
    }
    @objc public func set(_ call: CAPPluginCall) {
        local(call) {
            guard let value = call.getString("value"), let data = value.data(using: .utf8),
                  data.count <= 4096 else { call.reject("Invalid session"); return }
            let attributes: [String: Any] = [kSecValueData as String: data,
                kSecAttrAccessible as String: kSecAttrAccessibleWhenUnlockedThisDeviceOnly]
            var status = SecItemUpdate(self.query as CFDictionary, attributes as CFDictionary)
            if status == errSecItemNotFound {
                status = SecItemAdd(self.query.merging(attributes) { _, new in new } as CFDictionary, nil)
            }
            guard status == errSecSuccess else { call.reject("Secure session write failed"); return }
            call.resolve()
        }
    }
    @objc public func remove(_ call: CAPPluginCall) {
        local(call) {
            let status = SecItemDelete(self.query as CFDictionary)
            guard status == errSecSuccess || status == errSecItemNotFound else {
                call.reject("Secure session removal failed"); return
            }
            call.resolve()
        }
    }
}
