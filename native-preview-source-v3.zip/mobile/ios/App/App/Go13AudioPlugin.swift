import Foundation
import Capacitor
import AVFAudio
import UIKit

@objc(Go13AudioPlugin)
public class Go13AudioPlugin: CAPPlugin, CAPBridgedPlugin {
    public let identifier = "Go13AudioPlugin"
    public let jsName = "Go13Audio"
    public let pluginMethods: [CAPPluginMethod] = [
        CAPPluginMethod(name: "prepare", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "play", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "stop", returnType: CAPPluginReturnPromise)
    ]
    private var players: [String: AVAudioPlayer] = [:]
    private var observer: NSObjectProtocol?
    private let kinds = ["stone", "intro", "cue", "urgent"]
    private var trusted: Bool {
        guard let url = bridge?.webView?.url else { return false }
        return (url.scheme == "https" && url.host == "thirteen-go-test.onrender.com") ||
               (url.scheme == "capacitor" && url.host == "localhost")
    }
    public override func load() {
        observer = NotificationCenter.default.addObserver(forName: UIApplication.willResignActiveNotification, object: nil, queue: .main) { [weak self] _ in self?.silence() }
    }
    deinit { if let observer = observer { NotificationCenter.default.removeObserver(observer) } }
    private func silence() { for player in players.values { player.stop() } }
    @objc public func prepare(_ call: CAPPluginCall) {
        DispatchQueue.main.async { [weak self] in
            guard let self = self, self.trusted else { call.reject("Untrusted origin"); return }
            do {
                // Ambient obeys the iPhone Silent switch and does not interrupt music.
                try AVAudioSession.sharedInstance().setCategory(.ambient, mode: .default)
                try AVAudioSession.sharedInstance().setActive(true)
                for kind in self.kinds {
                    guard let url = Bundle.main.url(forResource: kind, withExtension: "wav", subdirectory: "public/audio") else { throw NSError(domain: "Go13Audio", code: 1) }
                    let player = try AVAudioPlayer(contentsOf: url)
                    player.prepareToPlay(); self.players[kind] = player
                }
                call.resolve()
            } catch { call.reject("Audio initialization unavailable") }
        }
    }
    @objc public func play(_ call: CAPPluginCall) {
        DispatchQueue.main.async { [weak self] in
            guard let self = self, self.trusted, UIApplication.shared.applicationState == .active,
                  let kind = call.getString("kind"), self.kinds.contains(kind), let player = self.players[kind] else { call.reject("Audio unavailable"); return }
            let volume = call.getDouble("volume") ?? 0.7
            let delay = call.getDouble("delay") ?? 0
            guard volume.isFinite, delay.isFinite else { call.reject("Invalid audio parameters"); return }
            player.stop(); player.currentTime = 0
            player.volume = Float(min(1, max(0, volume)))
            player.play(atTime: player.deviceCurrentTime + min(0.8, max(0, delay)))
            call.resolve()
        }
    }
    @objc public func stop(_ call: CAPPluginCall) {
        DispatchQueue.main.async { [weak self] in self?.silence(); call.resolve() }
    }
}

class Go13ViewController: CAPBridgeViewController {
    override func capacitorDidLoad() {
        bridge?.registerPluginInstance(Go13AudioPlugin())
        bridge?.registerPluginInstance(Go13SessionPlugin())
    }
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask { .portrait }
    override var shouldAutorotate: Bool { false }
}
