import {Capacitor,registerPlugin,CapacitorHttp} from '@capacitor/core';
import {StatusBar,Style} from '@capacitor/status-bar';
import {createAudioController} from './audio-controller.js';
import {createAppAdapter} from './app-adapter.js';
const native=Capacitor.isNativePlatform();
window.Go13Native=createAudioController({native,plugin:registerPlugin('Go13Audio'),isHidden:()=>document.hidden,onReady:()=>window.dispatchEvent(new Event('go13native:ready'))});
if(native){
  if(location.hostname==='localhost'&&['capacitor:','https:'].includes(location.protocol)){
    window.Go13App=createAppAdapter({request:async options=>{try{return await CapacitorHttp.request({...options,responseType:'text',disableRedirects:true,connectTimeout:15000,readTimeout:15000})}catch{throw Object.assign(Error('Native connection unavailable'),{code:'NATIVE_HTTP_FAILED'})}},plugin:registerPlugin('Go13Session'),assetFetch:window.fetch.bind(window)});
  }
  document.documentElement.classList.add('native-app');
  StatusBar.setStyle({style:Style.Dark}).catch(()=>{});
  window.Go13Native.initialize();
  document.addEventListener('visibilitychange',()=>{if(document.hidden)window.Go13Native.stop()});
}
