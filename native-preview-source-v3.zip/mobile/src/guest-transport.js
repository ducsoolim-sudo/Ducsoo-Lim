// Requires native HTTP plus a secure native token store, never localStorage.
// Kept separate from the active remote preview until device integration passes.
const origin='https://thirteen-go-test.onrender.com';
const paths=new Set(['/api/profile','/api/lobby','/api/rooms','/api/match','/api/test-match']);
export function createGuestTransport({request,sessionStore,now=()=>Date.now()/1000}){
  if(typeof request!=='function'||typeof sessionStore?.get!=='function'||typeof sessionStore?.set!=='function'||typeof sessionStore?.remove!=='function')throw Error('Native HTTP and secure session store are required');
  let pending=null;
  const expired=()=>Object.assign(Error('Native session expired. Restore or explicitly reset your guest identity.'),{code:'SESSION_EXPIRED'});
  const send=async(path,{method='GET',data,token}={})=>{
    const response=await request({url:origin+path,method,headers:{'Content-Type':'application/json',...(token?{Authorization:'Bearer '+token}:{})},...(data!==undefined?{data}:{})});
    if(response.status===401)throw expired();
    if(!Number.isInteger(response.status)||response.status<100||response.status>599)throw Error('Native server response unavailable');
    if(response.status<200||response.status>=300)throw Object.assign(Error('Native server request failed'),{code:'SERVER_RESPONSE',status:response.status,body:typeof response.data==='string'?response.data:JSON.stringify(response.data)});
    const body=typeof response.data==='string'?JSON.parse(response.data):response.data;
    return body;
  };
  const session=()=>{
    if(pending)return pending;
    pending=(async()=>{
      const stored=await sessionStore.get();
      if(stored!==null&&stored!==undefined){
        if(!valid(stored))throw expired();
        return stored;
      }
      const created=await send('/api/native/session',{method:'POST'});
      if(!valid(created))throw Error('Invalid native session response');
      await sessionStore.set(created);  // Persist before any room is created.
      return created;
    })().finally(()=>{pending=null});
    return pending;
  };
  function valid(value){return /^[A-Za-z0-9_-]{43}$/.test(value?.token||'')&&Number.isFinite(value?.expiresAt)&&value.expiresAt>now()}
  return {
    async api(path,{method='GET',data}={}){
      if(!paths.has(path)||!['GET','POST'].includes(method))throw Error('Unsupported native API');
      const {token}=await session();
      return send(path,{method,data,token});
    },
    async socketUrl(){
      const {token}=await session();
      const result=await send('/api/native/socket-ticket',{method:'POST',token});
      if(!/^[A-Za-z0-9_-]{43}$/.test(result?.ticket||''))throw Error('Invalid socket ticket');
      return origin.replace('https:','wss:')+'/ws/native?ticket='+encodeURIComponent(result.ticket);
    },
    async revoke(){
      const {token}=await session();
      await send('/api/native/revoke',{method:'POST',token});
      await sessionStore.remove();
    }
  };
}
