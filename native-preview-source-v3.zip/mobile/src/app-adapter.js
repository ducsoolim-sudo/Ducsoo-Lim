import {createGuestTransport} from './guest-transport.js';
export function createAppAdapter({request,plugin,assetFetch,ResponseType=Response}){
  const sessionStore={
    async get(){let result;try{result=await plugin.get()}catch{throw Object.assign(Error('Secure session read failed'),{code:'SECURE_READ_FAILED'})}const {value}=result;if(value===null)return null;if(typeof value!=='string')throw Error('Secure session unavailable');return JSON.parse(value)},
    async set(value){try{await plugin.set({value:JSON.stringify(value)})}catch{throw Object.assign(Error('Secure session write failed'),{code:'SECURE_WRITE_FAILED'})}},
    async remove(){await plugin.remove()}
  };
  const transport=createGuestTransport({request,sessionStore});
  return {
    socketUrl:()=>transport.socketUrl(),
    // Called only after an explicit UI confirmation; never on request failure.
    resetGuest:()=>sessionStore.remove(),
    async fetch(path,options={}){
      if(typeof path!=='string')throw Error('Unsupported app request');
      if(path.startsWith('/static/'))return assetFetch(path,options);
      if(path==='/api/auth/me')return new ResponseType(JSON.stringify({user:null,games:[]}),{status:200});
      let data;
      if(options.body!==undefined)data=JSON.parse(options.body);
      try{return new ResponseType(JSON.stringify(await transport.api(path,{method:options.method||'GET',data})),{status:200})}
      catch(error){if(error.code==='SERVER_RESPONSE')return new ResponseType(error.body,{status:error.status});throw error}
    }
  };
}
