export function createAudioController({native,plugin,isHidden=()=>false,onReady=()=>{}}){
  let ready=false;
  return {
    isNative:native,
    canPlay:()=>ready,
    async initialize(){if(!native)return false;try{await plugin.prepare();ready=true;onReady();return true}catch{ready=false;return false}},
    play(kind,volume=0.7,delay=0){
      if(!native||!ready||isHidden()||!['stone','intro','cue','urgent'].includes(kind)||!Number.isFinite(volume)||!Number.isFinite(delay))return false;
      plugin.play({kind,volume:Math.min(1,Math.max(0,volume)),delay:Math.min(0.8,Math.max(0,delay))}).catch(()=>{ready=false});
      return true;
    },
    stop(){if(native&&ready)plugin.stop().catch(()=>{})}
  };
}
