# 13GO 앱 개발용 첫 버전 · 0.1.0

## 현재 결과

기존 테스트 대국 서버를 사용하는 iOS/Android 네이티브 프로젝트다. 앱 식별자는 임시 `com.saistudio.go13.preview`, 이름은 `13GO Test`다. 두 플랫폼 프로젝트와 SAI STUDIO 아이콘, 세로 화면 설정, 자체 음향 플러그인, 인터넷 연결 실패 화면을 포함한다.

- 게스트 대국, 흑/백 AI 선택, 관전, 시간, 계가, 결과, 복기는 기존 서버를 사용한다.
- 네이티브 음향은 앱에 포함된 착수·시작·초읽기 WAV를 사용한다. iOS `.ambient`, Android 무음/진동 상태 확인을 구현했다. 앱 비활성화 시 소리와 지연 예약을 중단한다.
- 앱의 Google/Apple 로그인은 아직 구현하지 않았다. 웹 로그인 창을 앱 안에 띄워 성공한 것처럼 취급하지 않는다.
- 광고, 푸시, 오프라인 AI, 스토어 배포는 포함하지 않는다.
- 기본 설정은 원격 URL을 사용하는 **개발용** 설정이며, `sync:bundled`로 로컬 화면 개발 모드를 준비할 수 있다. Capacitor 공식 문서의 `server.url`은 개발용이므로 이 설정을 정식 출시용으로 제출하지 않는다. `npm run release:check`는 의도적으로 실패한다.

## 재현

Node 22 이상(이 작업은 Node 24), npm 필요.

```sh
cd mobile
npm ci
npm run sync
npm run check
```

`npm run sync`는 앱에 필요한 음향·연결 실패 화면과 `../mobile-bridge.js`를 생성하고 두 프로젝트에 복사한다. 보통의 웹 `/`는 네이티브 브리지를 로드하지 않는다. 개발용 `/mobile-preview`에서만 로드하며, 서버는 `GO13_PREVIEW=true`일 때만 이 경로를 제공한다. 서버 주소·허용 호스트는 테스트 서비스 하나로 고정했다. 운영 서비스나 로그인 보안 설정은 변경하지 않는다.

## 아이폰에서 다음 단계

### 빌드 준비 자동 점검

`npm run native:check`는 Node, JDK, Android SDK 36, Xcode와 의존성 설치 상태를 확인한다. 필요한 도구가 없으면 실패하고 이유를 표시한다. 이는 컴파일 성공을 보장하는 검사가 아니다.

- `npm run build:android`: 환경 점검 → 자산 생성 → Android 동기화 → 실제 Debug APK 빌드.
- `npm run build:ios`: 환경 점검 → 자산 생성 → iOS 동기화 → 서명 없는 iOS 시뮬레이터 빌드. 실제 아이폰 설치 파일은 만들지 않는다.

이 명령들은 SDK 약관 동의나 개발자 계정 가입을 대신 진행하지 않는다. Gradle/Xcode 자체 빌드가 성공해야 빌드 완료로 표시한다.

### 앱 내부 화면 포함 준비

`npm run stage:frontend`는 공유 화면, 로그인 스크립트, 음향과 네이티브 브리지를 `staged-frontend`에 묶고 SHA-256 자산 목록을 생성한다. 현재 개발용 `www`와 원격 서버 설정은 바꾸지 않는다. **이 결과는 아직 실행 가능한 오프라인 앱이 아니다.** 앱 전용 게스트 인증과 일회용 소켓 연결을 적용하며 로컬 앱 출처에서만 보안 저장소를 사용할 수 있다. 네이티브 컴파일·호스팅 서버의 기능 활성화·기기 검증은 남았다. `manifest.json`에 미완료 항목을 기록한다.

1. Mac에서 Xcode 설치 및 iOS 플랫폼 준비.
2. 위 재현 명령 후 `npm run open:ios`.
3. App 타깃의 Signing & Capabilities에서 본인의 Apple 개발 팀 선택. 실제 기기로 Debug 실행.
4. 착수음, 무음 스위치, 시작음, 초읽기, 회전, 백그라운드 복귀, 연결 끊김, 대국·복기를 실제 기기에서 확인.

이 환경에는 Mac/Xcode/애플 서명 인증서가 없어 iOS 컴파일·설치·TestFlight 업로드를 수행하지 못했다. Apple 계정 로그인이나 유료 개발자 가입도 진행하지 않았다.

## 안드로이드에서 다음 단계

JDK 21 및 Android Studio/SDK(API 36)가 필요하다. Android Studio에서 `mobile/android`를 열거나 SDK 준비 후 다음을 실행한다.

```sh
cd mobile/android
./gradlew assembleDebug
```

결과 경로는 `app/build/outputs/apk/debug/app-debug.apk`다. **현재 이 APK는 생성되지 않았다.** 현재 환경의 JDK는 17이고 Android SDK가 없어 네이티브 컴파일을 실행하지 못했다. SDK 이용약관을 임의로 승인하지 않았다.

## 정식 출시 전 남은 작업

### 앱 게스트 연결 기반 (2026-11-07)

`native_sessions.py`와 `src/guest-transport.js`에 앱 전용 게스트 세션과 소켓 접속권을 구현했다. 기존 웹 쿠키와 계정은 가져오지 않는다. 세션은 30일, 소켓 접속권은 30초·1회 사용이며 서버에는 원본 인증 문자열 대신 해시를 저장한다. 세션 취소 후에는 새 접속과 기존 소켓의 다음 메시지를 거부한다. 단일 서버 워커가 전제다.

이 기능은 `GO13_PREVIEW=true`와 `GO13_NATIVE_PREVIEW=true`가 모두 설정된 서버에서만 열린다. **2026-11-07 테스트 서버에 활성화했다.** 운영 서비스와 기존 웹 인증 흐름은 유지한다.

`createGuestTransport`는 네이티브 HTTP와 보안 저장소의 `get/set/remove` 구현을 주입받는다. 세션을 저장한 뒤에만 대국을 만들고, 인증 만료나 오류를 새 게스트 생성으로 덮어쓰지 않는다. 현재 원격 미리보기에는 연결하지 않았다. Keychain/Keystore 플러그인·네이티브 HTTP·로컬 화면의 소켓 연결은 다음 단계에서 구현했으며, 네이티브 컴파일과 실제 저장소·기기 검증이 남았다. 이 모듈만으로 앱을 닫고 여는 실제 기기 동작을 검증한 것은 아니다.

게스트 프로필·기록은 계정 동기화가 아니다. 테스트 서버 저장소가 초기화되면 복구되지 않는다. Google/Apple 등 계정 로그인은 별도 미완료 작업이다.

이번 변경은 서버 전체 148개 테스트, 모바일 모듈 검사 10개와 기존 웹 UI·복기 검사를 통과했다. 실제 HTTP/WebSocket 테스트에서 쿠키 없이 프로필·착수·동일 좌석 재접속을 확인했으며, 접속권 재사용·만료·다른 프로필의 좌석 탈취·세션 취소 후 착수를 거부했다. 휴대폰의 앱 종료·재실행이나 네이티브 보안 저장소 검증을 뜻하지 않는다.

- 프런트엔드 앱 내 포함 및 쿠키/네이티브 인증·재접속 설계 확정. 현재 원격 개발 설정 제거.
- 앱용 Google 및 Apple 로그인, 계정/결과 보존, 개인정보·스토어 등록 정보 검증.
- 실제 기기와 Xcode/Gradle 빌드 검증 및 서명, TestFlight/Play 내부 테스트.
- 서버 계가 미해결 예외와 AI 종국 판단의 추가 검증. 앱으로 포장한다고 서버 판정의 한계가 해결되지는 않는다.
- 테스트 서버는 일시 저장소이며 배포·휴면 시 기록이 초기화될 수 있다.

## 검증 범위

`npm run build`, `npx cap sync`, 음향 브리지 단위 테스트 3개와 프로젝트 설정 검사 2개를 통과했다. 네이티브 컴파일이나 실제 음향 청취 검증을 뜻하지 않는다. 기존 웹 화면 테스트·서버 전체 테스트 및 앱 진입 경로 격리 테스트를 수행했다.

## 참고

- https://capacitorjs.com/docs/config (server.url 개발용 제한)
- https://capacitorjs.com/docs/getting-started/environment-setup
- https://capacitorjs.com/docs/plugins/tutorial/ios-implementation
- https://capacitorjs.com/docs/plugins/tutorial/android-implementation
- Capacitor 및 의존성은 각 패키지의 라이선스를 따른다. 기존 SAI STUDIO 기호와 기존 프로젝트 음향을 재사용했다.

## 로컬 화면·보안 저장소 연결 (2026-11-07 후속 작업)

- iOS `Go13SessionPlugin`: Keychain의 `WhenUnlockedThisDeviceOnly`로 저장한다. 저장 실패·잠금·손상 오류를 새 게스트 생성으로 덮어쓰지 않는다.
- Android: Android Keystore의 AES 키와 GCM 암호문을 사용한다. SharedPreferences에는 IV와 암호문만 기록한다. 키 누락·복호화 오류는 실패로 처리하며 백업은 비활성화 상태다.
- 보안 저장소는 iOS `capacitor://localhost`, Android `https://localhost`의 앱 화면에서만 호출한다. 원격 웹 페이지에는 세션 저장소 접근을 허용하지 않는다.
- `Go13App`이 로컬 자산과 네이티브 HTTP 요청을 분리한다. 인증을 URL이나 localStorage에 넣지 않고, 네이티브 HTTP의 자동 리디렉션을 끈다. 기존 웹의 계정 쿠키를 앱 게스트로 가져오지 않는다.
- 로컬 앱 설정에서는 네이티브 브리지 로그를 끈다. 만료된 게스트는 자동 교체하지 않으며, My Page에 나타나는 Reset guest에서 현재 대국 접근을 잃는다는 확인 후에만 로컬 인증을 지울 수 있다.
- 로컬 화면에서 재접속마다 일회용 소켓 접속권을 발급받는다. 다른 방으로 이동하는 동안 완료된 이전 연결 요청은 버린다. 서버의 프로필 변경 제한 등 오류 메시지도 유지한다.

```sh
cd mobile
npm ci
npm run sync:bundled
npm run check
# 도구가 설치된 환경에서 실제 빌드
npm run build:android -- --bundled
npm run build:ios -- --bundled
```

`sync:bundled`는 플랫폼 프로젝트에 로컬 화면 설정을 복사하고, 원본 `capacitor.config.json`은 원격 미리보기 설정으로 복원한다. `npm run sync`를 다시 실행하면 플랫폼도 원격 미리보기 모드로 돌아간다. 로컬 개발 모드 역시 출시 승인을 의미하지 않는다.

**2026-11-07 테스트 서버에 네이티브 게스트 기능을 활성화했다.** 테스트 브랜치 커밋 `f96e2c058c4f59ef97c8bbfc4a641d6f7a378b13`, Render 배포 `dep-dbn7mbimcbas739lvbq0`가 live이며, `GO13_NATIVE_PREVIEW=true`를 기존 변수와 병합했다. 운영 서비스는 변경하지 않았다. 공개 환경변수 이름과 비밀값 없는 배포 식별자만 기록한다.

검증: 모바일 검사 13개(실제 로컬 Python 서버와 JS 앱 어댑터의 HTTP/WebSocket 대국·한 수 착수·동일 좌석 재접속 포함), 기존 웹 UI·복기 검사 통과. 연동 검사에서 네이티브 HTTP와 보안 저장소 인터페이스는 모의 구현이다. Swift/Java 네이티브 컴파일, Keychain/Keystore 실제 읽기·쓰기, 앱 강제 종료 후 복귀, 무음·음향·회전은 실제 기기에서 미검증 상태다. 설치 파일은 생성되지 않았다.

### 배포 서버 검증

`npm run verify:hosted -- --run`은 테스트 서비스만 대상으로 비공개 혼자두기 방을 만들고 한 수 착수·같은 좌석 재접속·기권 종료·인증 취소를 검사한다. 종료 뒤 인증을 폐기하며 인증 원문을 출력하지 않는다. 대국 상태 방송은 여러 번 올 수 있어 원하는 상태를 기다린 뒤 판정한다. 네이티브 HTTP·보안 저장소는 이 검사에서 모의 구현하므로 실제 휴대폰 검증을 대신하지 않는다. 2026-11-07 배포 후 모두 통과했다.
