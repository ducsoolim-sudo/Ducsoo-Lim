// Explicit test-service mutation. Uses memory in place of device secure storage.
import assert from 'node:assert/strict';
import {createAppAdapter} from '../src/app-adapter.js';
const origin='https://thirteen-go-test.onrender.com';
if(!process.argv.includes('--run')){
 console.error('Not run. Use --run to create a private solo room on the isolated test service.');process.exit(2);
}
let stored=null;const sockets=[];const checks=[];
const plugin={get:async()=>({value:stored}),set:async({value})=>{stored=value},remove:async()=>{stored=null}};
const request=async options=>{
 assert.equal(new URL(options.url).origin,origin);
 const response=await fetch(options.url,{method:options.method,headers:options.headers,redirect:'error',signal:AbortSignal.timeout(15000),...(options.data!==undefined?{body:JSON.stringify(options.data)}:{})});
 return {status:response.status,data:await response.text()};
};
const make=()=>createAppAdapter({request,plugin,assetFetch:fetch});
async function socketFor(adapter,room){
 const socket=new WebSocket(await adapter.socketUrl());sockets.push(socket);
 const messages=[];let wake;
 socket.addEventListener('message',e=>{messages.push(JSON.parse(e.data));wake?.();wake=null});
 const next=async()=>{if(!messages.length)await new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('Socket state timed out')),10000);wake=()=>{clearTimeout(timer);resolve()}});return messages.shift()};
 await new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('Socket connection timed out')),10000);socket.addEventListener('open',()=>{clearTimeout(timer);resolve()},{once:true});socket.addEventListener('error',()=>{clearTimeout(timer);reject(Error('Socket connection failed'))},{once:true})});
 socket.send(JSON.stringify({type:'join',room:room.room,token:room.token}));
 const welcome=await next();assert.equal(welcome.type,'welcome');assert.equal(welcome.role,'black');
 const until=async predicate=>{const deadline=Date.now()+10000;while(Date.now()<deadline){const message=await next();if(message.type==='error')throw Error('Server rejected test action');if(message.type==='state'&&predicate(message.state))return message.state}throw Error('Expected server state not received')};
 return {socket,next,until,state:await until(()=>true)};
}
async function close(socket){if(socket.readyState===WebSocket.CLOSED)return;await new Promise(resolve=>{const timer=setTimeout(resolve,3000);socket.addEventListener('close',()=>{clearTimeout(timer);resolve()},{once:true});socket.close()})}
let live=null;
try{
 const app=make();const first=await (await app.fetch('/api/profile')).json();assert(first.profile?.id);checks.push('guest-session');
 const roomResponse=await app.fetch('/api/rooms',{method:'POST',body:'{"solo":true}'});assert.equal(roomResponse.status,200);
 const room=await roomResponse.json();live=await socketFor(app,room);assert.equal(live.state.moves,0);
 live.socket.send(JSON.stringify({type:'move',index:84}));await live.until(state=>state.moves===1);checks.push('confirmed-move');
 await close(live.socket);live=null;
 const reopened=make();const second=await (await reopened.fetch('/api/profile')).json();assert.equal(second.profile.id,first.profile.id);
 live=await socketFor(reopened,room);assert.equal(live.state.moves,1);checks.push('same-profile-seat-and-board');
 live.socket.send(JSON.stringify({type:'resign'}));await live.until(state=>state.status==='finished');checks.push('finished-private-test');
 await close(live.socket);live=null;
 const {token}=JSON.parse(stored);
 assert.equal((await request({url:origin+'/api/native/revoke',method:'POST',headers:{Authorization:'Bearer '+token}})).status,200);
 await assert.rejects(reopened.fetch('/api/profile'),{code:'SESSION_EXPIRED'});checks.push('revoked-session-rejected');
 console.log(JSON.stringify({service:origin,passed:true,checks,scope:'Hosted guest protocol only; native HTTP and secure storage simulated, no phone or binary validation.'},null,2));
}catch(error){console.error('Hosted verification failed: '+error.message);process.exitCode=1}
finally{
 if(live?.socket.readyState===WebSocket.OPEN)live.socket.send(JSON.stringify({type:'resign'}));
 await Promise.allSettled(sockets.map(close));
 if(stored){const {token}=JSON.parse(stored);await request({url:origin+'/api/native/revoke',method:'POST',headers:{Authorization:'Bearer '+token}}).catch(()=>{});stored=null}
}
