"""Rasterize the existing SAI STUDIO geometric mark; no new logo artwork."""
from PIL import Image,ImageDraw
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def icon(size,transparent=False):
    scale=4;n=size*scale
    image=Image.new('RGBA',(n,n),(0,0,0,0) if transparent else '#101313');d=ImageDraw.Draw(image)
    factor=.7 if transparent else 1
    def coord(v):return int(n*(.5+(v-.5)*factor))
    for x in (.31,.69):d.line((coord(x),coord(.24),coord(x),coord(.76)),fill='#eeeee8',width=max(2,int(n*.022*factor)))
    r=n*.065*factor;c=n*.5;d.ellipse((c-r,c-r,c+r,c+r),fill='#eeeee8')
    image=image.resize((size,size),Image.Resampling.LANCZOS)
    return image if transparent else image.convert('RGB')
icon(1024).save(ROOT/'ios/App/App/Assets.xcassets/AppIcon.appiconset/AppIcon-512@2x.png')
for density,size in [('mdpi',48),('hdpi',72),('xhdpi',96),('xxhdpi',144),('xxxhdpi',192)]:
    folder=ROOT/'android/app/src/main/res'/('mipmap-'+density);folder.mkdir(parents=True,exist_ok=True)
    icon(size).save(folder/'ic_launcher.png');icon(size).save(folder/'ic_launcher_round.png');icon(int(size*2.25),True).save(folder/'ic_launcher_foreground.png')
