import {spawnSync} from 'node:child_process';
import {existsSync} from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const root=fileURLToPath(new URL('../',import.meta.url));
export function inspectEnvironment({platform,javaVersion='',sdk='',exists=existsSync,xcode=false,nodeMajor=Number(process.versions.node.split('.')[0])}){
 const common=nodeMajor>=22?[]:['Node 22 or newer'];
 const java=Number(javaVersion.match(/version\s+"(?:1\.)?(\d+)/)?.[1]||0);
 const android=[...common];
 if(java<21)android.push('JDK 21 or newer');
 if(!sdk)android.push('ANDROID_HOME or ANDROID_SDK_ROOT');
 else{
  if(!exists(path.join(sdk,'platforms','android-36','android.jar')))android.push('Android SDK platform 36');
  const adb=process.platform==='win32'?'adb.exe':'adb';
  if(!exists(path.join(sdk,'platform-tools',adb)))android.push('Android SDK platform-tools');
 }
 const ios=[...common];
 if(platform!=='darwin')ios.push('macOS with Xcode');
 else if(!xcode)ios.push('Xcode developer tools');
 return {android:{ready:android.length===0,missing:android},ios:{ready:ios.length===0,missing:ios}};
}
export function currentEnvironment(){
 const javaCommand=process.env.JAVA_HOME?path.join(process.env.JAVA_HOME,'bin',process.platform==='win32'?'java.exe':'java'):'java';
 const java=spawnSync(javaCommand,['-version'],{encoding:'utf8'});
 const xcode=process.platform==='darwin'&&spawnSync('xcodebuild',['-version'],{encoding:'utf8'}).status===0;
 const result=inspectEnvironment({platform:process.platform,javaVersion:java.stderr||java.stdout||'',sdk:process.env.ANDROID_HOME||process.env.ANDROID_SDK_ROOT||'',xcode});
 for(const target of ['android','ios'])if(!existsSync(path.join(root,'node_modules','@capacitor',target))) {result[target].missing.push('Run npm ci in mobile');result[target].ready=false;}
 return result;
}
