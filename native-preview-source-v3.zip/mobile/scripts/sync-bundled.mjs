// Restore source config even when native sync fails. Platform copies stay local.
import {readFile,writeFile,cp} from 'node:fs/promises';
import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
const root=fileURLToPath(new URL('../',import.meta.url));
const configPath=new URL('../capacitor.config.json',import.meta.url);
const original=await readFile(configPath,'utf8');
const run=args=>{const r=spawnSync(process.execPath,args,{cwd:root,stdio:'inherit'});if(r.error||r.status!==0)throw Error('Bundled sync failed')};
run(['scripts/build.mjs']);run(['scripts/stage-frontend.mjs']);
const config=JSON.parse(original);
config.loggingBehavior='none'; // Do not log native bridge session/HTTP payloads.
delete config.server.url;
config.server.hostname='localhost';config.server.iosScheme='capacitor';config.server.androidScheme='https';
try{
 await cp(new URL('../staged-frontend/',import.meta.url),new URL('../www/',import.meta.url),{recursive:true});
 await writeFile(configPath,JSON.stringify(config,null,2)+'\n');
 run(['node_modules/@capacitor/cli/bin/capacitor','sync',...process.argv.slice(2)]);
}finally{await writeFile(configPath,original)}
console.log('Native projects now use local assets. Source remote-preview config restored. This is not a signed or device-verified build.');
