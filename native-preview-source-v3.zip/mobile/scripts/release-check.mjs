import {readFile} from 'node:fs/promises';
const config=JSON.parse(await readFile(new URL('../capacitor.config.json',import.meta.url),'utf8'));
if(config.server?.url){console.error('RELEASE BLOCKED: this is a remote-server development preview. Bundle the frontend, finish native sign-in, and validate devices before store submission.');process.exit(1)}
console.log('No remote development URL; signing, privacy, device and store checks still required.');
