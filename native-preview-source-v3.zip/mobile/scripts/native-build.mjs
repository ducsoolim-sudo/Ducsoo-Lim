import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {currentEnvironment} from './native-environment.mjs';
const root=fileURLToPath(new URL('../',import.meta.url));
const target=process.argv[2];
if(!['android','ios','check'].includes(target)){console.error('Use check, android or ios');process.exit(2)}
const state=currentEnvironment();
if(target==='check'){console.log(JSON.stringify(state,null,2));process.exit(state.android.ready||state.ios.ready?0:1)}
if(!state[target].ready){console.error('BUILD NOT RUN: '+state[target].missing.join('; '));process.exit(1)}
const run=(cmd,args,cwd=root)=>{const r=spawnSync(cmd,args,{cwd,stdio:'inherit'});if(r.error){console.error(r.error.message);process.exit(1)}if(r.status!==0)process.exit(r.status||1)};
if(process.argv.includes('--bundled'))run(process.execPath,['scripts/sync-bundled.mjs',target]);
else{
 run(process.execPath,['scripts/build.mjs']);
 run(process.execPath,['node_modules/@capacitor/cli/bin/capacitor','sync',target]);
}
if(target==='android')run('./gradlew',['assembleDebug','--no-daemon'],fileURLToPath(new URL('../android',import.meta.url)));
else run('xcodebuild',['-project','ios/App/App.xcodeproj','-scheme','App','-configuration','Debug','-destination','generic/platform=iOS Simulator','-derivedDataPath','build/ios-simulator','CODE_SIGNING_ALLOWED=NO','build']);
console.log(target==='android'?'Debug APK: android/app/build/outputs/apk/debug/app-debug.apk':'Simulator build finished. This is not a signed iPhone installation.');
