# 연습 대국 색상·종국 수정 · 2026-11-05

- Play의 연습 색상 선택: Black · First / White · Second. 서버가 입력을 검증하고 백 선택 시 AI의 흑 좌석을 먼저 예약한다. 봇의 실제 역할을 기준으로 착수·확인·재대국 처리한다. 기본값은 흑.
- 강한 AI가 패스를 제안해도 엄격한 settled_adjudication 증명이 없으면 거부하던 코드를 제거했다. 합법적인 패스 선택과 최종 결과 검증을 분리했다. 최종 계가의 불확실성 방어는 유지한다.
- 보조 AI는 완전히 판정 가능한 종국에서 먼저 패스한다. 자기 돌로만 둘러싸인 작은 빈 영역의 불필요한 착수는 제외하되, 잡기·약한 돌 방어는 허용한다. 이 휴리스틱은 모든 사활·패 상황의 완전 판정이 아니다.
- 상단 이름 크기·굵기·자간과 심볼 간격을 맞췄다. 통합 홈과 착수음은 유지한다.

검증: test_practice_options, test_bot_strength, test_preview_bot, test_manners, test_auto_flow 27개 통과. 백 사용자 실제 소켓 접속 후 AI 흑 첫 수·백 차례 검증. 엔진 패스 우선 선택, 흑 AI의 색상, 보조 AI의 종국 패스, 잘못된 색상 거부 포함. test_profile.cjs, test_review.cjs 통과.

테스트 배포 소스: 718efb1459c5854847a919031e818ba2fb1bcac9. 운영 배포 없음. 실제 기기에서의 복잡한 종국·사활 검증은 별도 필요.

배포 live: dep-dblupsgae00c73fqfmag. 실제 브라우저 ZPF8VTB에서 White · Second 선택 → Test Bot 흑 / Player 백 배정 → AI 흑 선착수 → 백 착수 입력 확인. 선택 화면과 상단 디자인 기록 저장.
