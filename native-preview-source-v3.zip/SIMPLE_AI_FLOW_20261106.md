# 간결한 AI 진입과 시간 설정 · 2026-11-06

사용자 기준: 간결·편의·고급스러움.

- 두 번째 화면 로고 40px, 두 이름 14px로 비례 수정. 작은 화면은 로고 36px와 이름 11.5px. 대국 중에는 이름 12px로 보드 공간을 보존.
- Play with AI → Black / White 선택창 → 즉시 대국. 기존 Practice color, First, Second 제거. 닫기·Escape·Tab 순환 지원.
- 새 대국은 기본 300초 + 초읽기 10초 3회. 서버·화면·SGF가 같은 설정 사용. 기존 저장 대국은 30초 설정 보존.
- 10초 각 초마다 효과음 호출. 중복 수신 시 한 번만 재생. 실제 iPhone 청취는 별도 확인 필요.

검증: 전체 Python 138개 통과. test_profile.cjs와 test_review.cjs 통과. 10초 경계·기간 차감·착수 리셋·기존 30초 기보 복원·매초 효과음 중복 억제·AI 선택창 노출/닫기 검사 포함. 이전 변경으로 낡은 solo/Temporary games HTML 기대값을 현행 UI 기준으로 갱신.

테스트 원격 커밋 7c4a2dcf3fb53b86993ec7231fdb515ec4d53124. 운영 배포 없음.

실제 배포 검증: dep-dbmh3qbbc2fs738cedig live. Play 화면에는 두 대국 버튼만 표시. Play with AI를 누른 뒤 Black/White 창이 표시되고 White 선택으로 실제 백 좌석 연결, 흑 AI 선착수, 5 min + 10 sec × 3 표시 확인. 검증 대국 기권 후 Home/Play 복귀 확인. 실제 휴대폰 청취는 미확인.
