// Prepare shared UI assets without changing the working remote preview.
// This output is an integration input, not an installable/offline game.
import {readFile,writeFile,mkdir,copyFile,rm} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
const root=fileURLToPath(new URL('../',import.meta.url));
const repo=path.dirname(root.replace(/\/$/,''));
const out=path.join(root,'staged-frontend');
await rm(out,{recursive:true,force:true});
await mkdir(path.join(out,'static'),{recursive:true});
let html=await readFile(path.join(repo,'index.html'),'utf8');
if(!html.includes('<script>'))throw Error('Shared UI script insertion point missing');
const socketLine="const ws=new WebSocket(protocol+'//'+location.host+'/ws');socket=ws;";
if(!html.includes(socketLine)||!html.includes('function connect(){'))throw Error('Socket integration point missing');
html=html.replace(/\bfetch\(/g,'appFetch(')
 .replace('<script>',`<script>
function offerGuestReset(){
 if(document.getElementById('nativeGuestReset'))return;
 const button=document.createElement('button');button.id='nativeGuestReset';button.className='button ghost';button.textContent='Reset guest';
 button.onclick=async()=>{if(!confirm('Reset this guest identity? Access to your current game will be lost.'))return;button.disabled=true;try{await window.Go13App.resetGuest();for(const key of Object.keys(localStorage))if(key==='13go:active-room'||key==='13go:nickname'||/^13go:[A-Z]{6}$/.test(key))localStorage.removeItem(key);location.replace(location.pathname)}catch{button.disabled=false;button.textContent='Try reset again'}};
 document.querySelector('.profile-account-actions').append(button);
}
const appFetch=(...args)=>window.Go13App?window.Go13App.fetch(...args).catch(error=>{if(error.code==='SESSION_EXPIRED')offerGuestReset();throw error}):Promise.reject(new Error('Native app required'));
`)
 .replace('function connect(){','let nativeConnectEpoch=0;\n  async function connect(){')
 .replace(socketLine,`const targetRoom=room,epoch=++nativeConnectEpoch;let endpoint;
    try{endpoint=await window.Go13App.socketUrl()}catch(error){if(epoch!==nativeConnectEpoch||room!==targetRoom)return;connection('Connection unavailable');if(error.code!=='SESSION_EXPIRED'){clearTimeout(reconnectTimeout);reconnectTimeout=setTimeout(connect,Math.min(1000*Math.pow(1.7,retry++),8000))}else{offerGuestReset();toast('Session expired. Open My Page to reset your guest identity.')}return}
    if(epoch!==nativeConnectEpoch||room!==targetRoom)return;
    const ws=new WebSocket(endpoint);socket=ws;`);
await writeFile(path.join(out,'index.html'),html.replace('<script>','<script src="/static/mobile-bridge.js"></script>\n<script>'));
for(const file of ['social-login.js','stone-placement.wav','brand-intro.wav','mobile-bridge.js'])await copyFile(path.join(repo,file),path.join(out,'static',file));
const files=['index.html',...['social-login.js','stone-placement.wav','brand-intro.wav','mobile-bridge.js'].map(f=>'static/'+f)];
const assets=[];
for(const file of files){const data=await readFile(path.join(out,file));assets.push({file,bytes:data.length,sha256:createHash('sha256').update(data).digest('hex')});}
await writeFile(path.join(out,'manifest.json'),JSON.stringify({format:1,purpose:'native-frontend-integration',runnable:false,blockers:['native-compilation','hosted-native-preview-activation','native-sign-in','device-validation'],assets},null,2)+'\n');
console.log('Staged bundled guest transport. Active preview config unchanged; native compilation and device checks still required.');
